<?php
define('DB_HOST', '198.59.144.15'); 
define('DB_USER', 'jassosmx_darkNight');  
define('DB_PASSWORD', 'Fs)Fx%-y1kmD');   
define('DB_NAME', 'jassosmx_sij'); 
define('SITE_NAME', 'Mi Sitio Web');
?>






