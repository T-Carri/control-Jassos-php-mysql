<?php
// Configuración de la base de datos
define('DB_HOST', '127.0.0.1');  // Reemplaza con la dirección del servidor de la base de datos
define('DB_USER', 'root');   // Reemplaza con el nombre de usuario de la base de datos
define('DB_PASSWORD', '');   // Reemplaza con la contraseña de la base de datos
define('DB_NAME', 'sij_localhost'); // Reemplaza con el nombre de la base de datos

// Otras configuraciones globales, si es necesario
define('SITE_NAME', 'Mi Sitio Web');
?>